# Trade Log - Livermore-MML

## Portfolio Summary

| Metric | Value |
|--------|-------|
| Starting Capital | $10,000 |
| Current Value | $10,000 |
| Total ROI | 0% |
| Win Rate | — |
| Total Trades | 0 |
| Winning Trades | 0 |
| Losing Trades | 0 |
| Avg Win | — |
| Avg Loss | — |
| Largest Win | — |
| Largest Loss | — |

---

## Trade Entry Template

| Field | Value |
|-------|-------|
| Trade # | |
| Date Entered | |
| Coin | |
| Direction | LONG / SHORT |
| Entry Price | |
| Position Size ($) | |
| Position Size (%) | |
| MML Level Entry | |
| Stop Loss | |
| TP1 (MML) | |
| TP2 (MML) | |
| Reason/Notes | |

---

## Trade Exit Template

| Field | Value |
|-------|-------|
| Date Exited | |
| Exit Price | |
| Exit Reason | TP1 / TP2 / STOP / MANUAL / CLIMAX |
| P/L ($) | |
| P/L (%) | |
| Result | WIN / LOSS |
| Lessons Learned | |

---

## Active Positions

| # | Coin | Entry | Current | P/L % | MML | Stop | TP1 | TP2 |
|---|------|-------|---------|-------|-----|------|-----|-----|
| 1 | AAVE | $123.35 | | | | | | |
| 2 | BCH | $556.18 | | | | | | |
| 3 | SOL | $82.20 | | | | | | |

---

## Trade History

| # | Date | Coin | Dir | Entry | Exit | P/L $ | P/L % | Result |
|---|------|------|-----|-------|------|-------|--------|--------|
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |
| 4 | | | | | | | | |
| 5 | | | | | | | | |
| 6 | | | | | | | | |
| 7 | | | | | | | | |
| 8 | | | | | | | | |
| 9 | | | | | | | | |
| 10 | | | | | | | | |

---

## Monthly Summary

| Month | Trades | Wins | Losses | Win % | Net P/L |
|-------|--------|------|--------|-------|---------|
| | | | | | |
| | | | | | |
| | | | | | |
