# Trade Entry - #[number]

**Date:** [YYYY-MM-DD HH:MM]
**Coin:** [CODE]
**Action:** BUY / SELL

**Entry Price:** $[price]
**Exit Price:** $[price] (fill when closed)
**Amount:** $[amount]
**Size:** [% of portfolio]

**Reason:** [entry signal]
**Exit Reason:** [exit signal] (fill when closed)

**P/L:** $[amount] / [%]

---

## Trade History (reverse chronological)

### Trade #1 - [DATE]
- Coin: [CODE]
- Entry: $[price]
- Exit: $[price]
- P/L: $[amount] ([%])
- Result: WIN / LOSE
- Notes: [what worked/didn't]
