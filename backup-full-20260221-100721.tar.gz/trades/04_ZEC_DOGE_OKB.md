# Trade #4 - ZEC

**Date:** 2026-02-20 06:35 UTC
**Coin:** ZEC (Zcash)
**Action:** BUY

**Entry Price:** $264.57
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +15.06%, green today (+0.69%), solid volume ($281M), privacy coin strength

**Exit Reason:** -

**P/L:** -

**Status:** OPEN

---

## Trade #5 - DOGE

**Date:** 2026-02-20 06:35 UTC
**Coin:** DOGE (Dogecoin)
**Action:** BUY

**Entry Price:** $0.0988
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +7.08%, green today (+0.47%), huge volume ($783M), meme strength

**Exit Reason:** -

**P/L:** -

**Status:** OPEN

---

## Trade #6 - OKB

**Date:** 2026-02-20 06:35 UTC
**Coin:** OKB
**Action:** BUY

**Entry Price:** $79.54
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +6.46%, green today (+2.03%), exchange token momentum

**Exit Reason:** -

**P/L:** -

**Status:** OPEN
