# Watchlist

## Coins to Watch

| Coin | Price | 24h | Weekly | Notes |
|------|-------|-----|--------|-------|
| KAS | $0.0316 | +6.12% | -4.12% | Daily green, weekly red |
| NEAR | ~$1.10 | +8% | +5.97% | ✅ In position |

---

## Notes

- KAS: Weekly needs to flip green for entry
