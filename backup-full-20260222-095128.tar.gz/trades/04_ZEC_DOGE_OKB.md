# Trade #4 - ZEC

**Date:** 2026-02-20 06:35 UTC
**Coin:** ZEC (Zcash)
**Action:** BUY

**Entry Price:** $264.57
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +15.06%, green today (+0.69%), solid volume ($281M), privacy coin strength

**Exit Reason:** -

**P/L:** -

**Status:** OPEN
