# Trade #3 - SOL

**Date:** 2026-02-19 20:52 UTC
**Coin:** SOL (Solana)
**Action:** BUY

**Entry Price:** $82.20
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +6.9%, green today, huge volume ($2.47B), top 10 crypto

**Exit Reason:** -

**P/L:** -

**Status:** OPEN
