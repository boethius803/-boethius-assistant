# Trade #1 - AAVE

**Date:** 2026-02-19 20:52 UTC
**Coin:** AAVE
**Action:** BUY

**Entry Price:** $123.35
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +12.5%, green today, high volume ($905M), top DeFi coin

**Exit Reason:** -

**P/L:** - 

**Status:** OPEN
