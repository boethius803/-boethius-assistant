# Trade #7 - TAO (Bittensor)

**Date:** 2026-02-20 15:58 UTC
**Coin:** TAO (Bittensor)
**Action:** BUY

**Entry Price:** $181.07
**Exit Price:** -
**Amount:** $1,000
**Size:** 20% of available cash

**Reason:** Livermore Advance - weekly +13.3%, daily green (+3.3%), AI/nodes sector strength

**Exit Reason:** -

**P/L:** -

**Status:** OPEN

---

## Exit Plan
- Stop: $172.02 (-5% = -$50)
- TP1: $199.18 (+10% = +$100) — sell 40%
- TP2: $217.28 (+20% = +$200) — sell 40%
- Runner: Let 20% ride with -2% trailing
