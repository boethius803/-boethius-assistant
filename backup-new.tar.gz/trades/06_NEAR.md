# Trade #8 - NEAR

**Date:** 2026-02-21
**Coin:** NEAR Protocol
**Action:** BUY

**Entry Price:** $1.10
**Exit Price:** -
**Amount:** $800
**Size:** 20% of available cash

**Reason:** Livermore weekly +5.97%, daily +8.04% - strong momentum uptrend

**Exit Reason:** -

**P/L:** -

**Status:** OPEN
