# Trade #2 - BCH

**Date:** 2026-02-19 20:52 UTC
**Coin:** BCH (Bitcoin Cash)
**Action:** BUY

**Entry Price:** $556.18
**Exit Price:** -
**Amount:** $1,000
**Size:** 10% of portfolio

**Reason:** Livermore Advance phase - weekly +10.6%, green today, solid volume ($202M), BTC fork momentum

**Exit Reason:** -

**P/L:** -

**Status:** OPEN
